// pipeline
// on data_upload

// Entry point of the orders pipeline. Paste (or tweak) the order export in
// the run form and hit Run — every downstream script cascades automatically
// through its `// on datatable://…` subscription. This is the production
// dispatch, not a simulation.
import * as wmill from "windmill-client";

export async function main(orders: any[]) {
  if (!Array.isArray(orders) || orders.length === 0) {
    throw new Error("expected a non-empty JSON array of orders");
  }
  const dt = wmill.datatable("main");
  await dt`CREATE TABLE IF NOT EXISTS orders_raw (
    order_id text,
    product text,
    category text,
    qty int,
    unit_price double precision,
    currency text,
    ordered_at timestamp
  )`.fetch();
  await dt`DELETE FROM orders_raw`.fetch();
  for (const r of orders) {
    await dt`INSERT INTO orders_raw (order_id, product, category, qty, unit_price, currency, ordered_at)
      VALUES (${r.order_id}, ${r.product}, ${r.category}, ${r.qty}, ${r.unit_price}, ${r.currency}, CAST(${r.ordered_at} AS timestamp))`.fetch();
  }
  return { ingested: orders.length };
}
