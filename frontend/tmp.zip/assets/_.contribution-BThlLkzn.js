const s=class s{get layoutInfos(){return this._layoutInfos}constructor(){this._layoutInfos=[]}registerKeyboardLayout(a){this._layoutInfos.push(a)}};s.INSTANCE=new s;let t=s;export{t as K};
