# Change Log

<!-- ## [Unreleased] -->

## [0.3.2]
- merged latest language tools (Nov 6. 2021, v0.14.11)
- e2e tests

## [0.2.1]
- goto defenition/declartion - fix in vscode.dev vfs

## [0.2.0]
- tsconfig lib support - project base 'tsconfig.json' should now be parsed and matching lib decalation files added
- goto defenition/declartion

## [0.1.0]
- typescript virtual filesystem and module resultion