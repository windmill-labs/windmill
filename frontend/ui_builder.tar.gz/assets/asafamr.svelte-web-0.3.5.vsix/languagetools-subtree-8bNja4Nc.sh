# inital was
# git subtree add --prefix vendored/langauge-tools https://github.com/sveltejs/language-tools.git master --squash
git subtree pull --prefix vendored/langauge-tools https://github.com/sveltejs/language-tools.git master --squash


